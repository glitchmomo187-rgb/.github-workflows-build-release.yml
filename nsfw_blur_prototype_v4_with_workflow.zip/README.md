# NSFW Blur Prototype (Android, Kotlin)

**What this is**
- An Android Studio project skeleton for a prototype app that:
  * Runs on Android (minSdk 24+)
  * Requests MediaProjection (screen capture) and Overlay permissions
  * Captures one frame every ~2 seconds
  * Uses a simple on-device heuristic (naive skin-tone ratio) to detect potentially explicit frames
  * When flagged, displays a permanent blur overlay that cannot be dismissed by the user (no bypass UI)

**Important**
- This is a prototype/demo. The naive classifier is not production-grade.
- To improve detection accuracy, replace `NSFWClassifier.kt` with a TensorFlow Lite model (e.g., MobileNet-based NSFW model) and update the code to run the TFLite interpreter.
- The project does not include a TFLite model file due to licensing/size constraints.

**How to run**
1. Unzip the project and open it in Android Studio.
2. Connect an Android device (or emulator with Google Play services and API >= 24).
3. Build & Run.
4. When app opens, press "Start Protection", grant screen capture permission and SYSTEM_ALERT_WINDOW overlay permission.

**Notes on behavior**
- The app captures the screen at low rate and analyses frames.
- If a frame is flagged, it shows a full-screen blur overlay that cannot be removed by the user (appmatically enforced).
- The overlay covers all other apps including Chrome, YouTube, Facebook, and messaging apps.

**Files included**
- `app/src/main/AndroidManifest.xml`
- `app/build.gradle`
- `app/src/main/java/com/example/nsfwblur/MainActivity.kt`
- `app/src/main/java/com/example/nsfwblur/BackgroundService.kt`
- `app/src/main/java/com/example/nsfwblur/OverlayManager.kt`
- `app/src/main/java/com/example/nsfwblur/NSFWClassifier.kt` (naive placeholder)
- Layouts and a simple icon.

**If you want a production-ready version**
- I can help convert the classifier to TFLite, integrate a high-quality on-device NSFW model, and optimize battery/CPU usage.
