package com.example.nsfwblur

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class BackgroundService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var handler = Handler(Looper.getMainLooper())
    private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification: Notification = NotificationCompat.Builder(this, "nsfw_channel")
            .setContentTitle("NSFW Blur")
            .setContentText("Protection running")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .build()
        startForeground(1, notification)

        val data = intent?.getParcelableExtra<Intent>("data")
        if (data != null) {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(Activity.RESULT_OK, data)
            startCapture()
        }
        return START_STICKY
    }

    private fun startCapture() {
        if (mediaProjection == null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        val density = metrics.densityDpi
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        imageReader = ImageReader.newInstance(width, height, 0x1, 2) // PixelFormat.RGBA_8888 = 1
        val surface = imageReader!!.surface
        mediaProjection?.createVirtualDisplay("nsfw-capture", width, height, density, 0, surface, null, null)

        imageReader!!.setOnImageAvailableListener({ reader ->
            val image: Image? = reader.acquireLatestImage()
            if (image != null) {
                val bmp = imageToBitmap(image)
                image.close()
                handleFrame(bmp)
            }
        }, handler)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val width = image.width
        val height = image.height
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        // This is a simplified conversion; may produce rotated output on some devices.
        val bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(bmp, 0, 0, width, height)
    }

    private fun handleFrame(bitmap: Bitmap) {
        // downscale to speed up
        val small = Bitmap.createScaledBitmap(bitmap, 160, 160, true)
        val score = NSFWClassifier.classify(small)
        if (score > 0.5f) {
            OverlayManager.showBlurOverlay(this)
        } else {
            // keep overlay if already shown (policy: once flagged, remain blurred)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel("nsfw_channel", "NSFW Blur", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }
}
