package com.example.nsfwblur

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val REQUEST_MEDIA_PROJECTION = 1001
    private lateinit var projectionManager: MediaProjectionManager

    // Admin default credentials stored in SharedPreferences (default user=admin, pass=glitch)
    private val PREFS = "protect_prefs"
    private val KEY_USER = "admin_user"
    private val KEY_PASS = "admin_pass"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ensure default credentials exist
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_USER)) {
            prefs.edit().putString(KEY_USER, "admin").putString(KEY_PASS, "glitch").apply()
        }

        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        // Build a simple Arabic UI programmatically
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(40,40,40,40)

        val title = TextView(this)
        title.text = "حماية المحتوى - Protect yourself"
        title.textSize = 20f
        layout.addView(title)

        val btn = Button(this)
        btn.text = "بدء الحماية"
        btn.setOnClickListener {
            // ask for overlay permission if needed
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(this)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                    startActivity(intent)
                    return@setOnClickListener
                }
            }
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION)
        }
        layout.addView(btn)

        val adminBtn = Button(this)
        adminBtn.text = "تسجيل دخول الأدمن"
        adminBtn.setOnClickListener { showAdminLogin() }
        layout.addView(adminBtn)

        val info = TextView(this)
        info.text = "التطبيق يقوم بتحليل الشاشة محليًا ويغطي الصور غير المناسبة بطبقة غير قابلة للإزالة للمستخدم العادي."
        layout.addView(info)

        setContentView(layout)
    }

    private fun showAdminLogin() {
        val dialogLayout = LinearLayout(this)
        dialogLayout.orientation = LinearLayout.VERTICAL
        val userEt = EditText(this)
        userEt.hint = "اسم المستخدم"
        val passEt = EditText(this)
        passEt.hint = "كلمة المرور"
        passEt.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        dialogLayout.addView(userEt)
        dialogLayout.addView(passEt)

        AlertDialog.Builder(this)
            .setTitle("دخول الأدمن")
            .setView(dialogLayout)
            .setPositiveButton("دخول") { d, _ ->
                val user = userEt.text.toString()
                val pass = passEt.text.toString()
                val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val savedUser = prefs.getString(KEY_USER, "admin")
                val savedPass = prefs.getString(KEY_PASS, "glitch")
                if (user == savedUser && pass == savedPass) {
                    showAdminSettings()
                } else {
                    AlertDialog.Builder(this).setMessage("بيانات غير صحيحة").setPositiveButton("حسناً", null).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showAdminSettings() {
        val items = arrayOf("تغيير كلمة المرور", "إيقاف الحماية (للمشرف فقط)", "فتح إعدادات التطبيق")
        AlertDialog.Builder(this)
            .setTitle("إعدادات الأدمن")
            .setItems(items) { _, which ->
                when(which) {
                    0 -> showChangePassword()
                    1 -> stopProtection()
                    2 -> openAppSettings()
                }
            }
            .show()
    }

    private fun showChangePassword() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val dialogLayout = LinearLayout(this)
        dialogLayout.orientation = LinearLayout.VERTICAL
        val oldEt = EditText(this)
        oldEt.hint = "كلمة المرور القديمة"
        oldEt.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        val newEt = EditText(this)
        newEt.hint = "كلمة المرور الجديدة"
        newEt.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        val confirmEt = EditText(this)
        confirmEt.hint = "تأكيد كلمة المرور الجديدة"
        confirmEt.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        dialogLayout.addView(oldEt)
        dialogLayout.addView(newEt)
        dialogLayout.addView(confirmEt)

        AlertDialog.Builder(this)
            .setTitle("تغيير كلمة المرور")
            .setView(dialogLayout)
            .setPositiveButton("تغيير") { d, _ ->
                val old = oldEt.text.toString()
                val n = newEt.text.toString()
                val c = confirmEt.text.toString()
                val savedPass = prefs.getString(KEY_PASS, "glitch")
                if (old != savedPass) {
                    AlertDialog.Builder(this).setMessage("كلمة المرور القديمة غير صحيحة").setPositiveButton("حسناً", null).show()
                    return@setPositiveButton
                }
                if (n.isEmpty() || n != c) {
                    AlertDialog.Builder(this).setMessage("كلمة المرور الجديدة غير متطابقة أو فارغة").setPositiveButton("حسناً", null).show()
                    return@setPositiveButton
                }
                // save new password
                prefs.edit().putString(KEY_PASS, n).apply()
                AlertDialog.Builder(this).setMessage("تم تغيير كلمة المرور").setPositiveButton("حسناً", null).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun stopProtection() {
        val intent = Intent(this, BackgroundService::class.java)
        stopService(intent)
        AlertDialog.Builder(this).setMessage("تم إيقاف الحماية").setPositiveButton("حسناً", null).show()
    }

    private fun openAppSettings() {
        val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = android.net.Uri.parse("package:" + packageName)
        startActivity(intent)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK) {
            val intent = Intent(this, BackgroundService::class.java)
            intent.putExtra("data", data)
            ContextCompat.startForegroundService(this, intent)
            AlertDialog.Builder(this)
                .setTitle("بدء الحماية")
                .setMessage("الخدمة تعمل الآن في الخلفية.")
                .setPositiveButton("حسناً", null)
                .show()
        }
    }
}
