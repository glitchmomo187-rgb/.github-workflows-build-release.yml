package com.example.nsfwblur

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager

object OverlayManager {
    private var overlayView: View? = null

    fun showBlurOverlay(context: Context) {
        if (overlayView != null) return
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(android.R.layout.screen_background_light, null)
        // make the view strongly opaque to prevent seeing content
        view.alpha = 0.95f
        wm.addView(view, params)
        overlayView = view
    }

    // No hide function exposed to user; overlay remains once shown
    fun hideOverlay(context: Context) {
        overlayView?.let {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(it)
            overlayView = null
        }
    }
}
