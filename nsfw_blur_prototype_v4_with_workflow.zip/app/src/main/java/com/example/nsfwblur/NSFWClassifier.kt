package com.example.nsfwblur

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

object NSFWClassifier {
    // Naive skin-tone ratio classifier as placeholder.
    // Returns 0..1 score. Not accurate — replace with TFLite model for production.
    fun classify(bmp: Bitmap): Float {
        var skin = 0
        var total = 0
        val w = bmp.width
        val h = bmp.height
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        for (p in pixels) {
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            total++
            // Simple skin color rule in RGB
            val maxc = max(r, max(g, b))
            val minc = min(r, min(g, b))
            if (r > 95 && g > 40 && b > 20 && (maxc - minc) > 15 && kotlin.math.abs(r - g) > 15 && r > g && r > b) {
                skin++
            }
        }
        val ratio = skin.toFloat() / total.toFloat()
        return ratio // higher ratio -> more likely NSFW by this naive metric
    }
}
